from django.apps import AppConfig


class ClassroombookingPjConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'classroombooking_pj'
