from django.apps import AppConfig


class ClassroombookingappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'classroombookingapp'
